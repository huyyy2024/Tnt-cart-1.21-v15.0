package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runtime v15 — ht1-legit:
 * - 1 rail + 1 cart per arrow, guaranteed
 * - Rotation toward block trước khi interact (Grim fix)
 * - Timing tự nhiên có variance
 * - beforeSync grim pattern
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Dedup entity
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_TTL = 3000L;

    // Dedup position
    private final Set<BlockPos> recentDone =
        Collections.newSetFromMap(new ConcurrentHashMap<>());

    // Pending carts
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_RETRY = 8;

    // Bow release precomputed
    private volatile BlockPos precomputedRailPos = null;
    private volatile long     precomputedAtMs    = 0L;
    private static final long PRECOMPUTED_TTL_MS = 2000L;

    private final TickSynchronizer tickSync = new TickSynchronizer();
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    public void storePrecomputedPos(BlockPos pos) {
        precomputedRailPos = pos;
        precomputedAtMs    = System.currentTimeMillis();
    }

    public BlockPos getAndClearPrecomputed() {
        BlockPos pos = precomputedRailPos;
        if (pos == null) return null;
        if (System.currentTimeMillis() - precomputedAtMs > PRECOMPUTED_TTL_MS) {
            precomputedRailPos = null;
            return null;
        }
        precomputedRailPos = null;
        return pos;
    }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    public boolean wasRecentlyPlaced(BlockPos pos) {
        return recentDone.contains(pos);
    }

    /**
     * Gọi sau khi đặt rail — schedule cart + dedup.
     */
    public void acceptArrow(int entityId, BlockPos railPos, int cartDelay) {
        if (recentDone.contains(railPos)) return;
        recentDone.add(railPos);
        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> {
            acceptedArrows.remove(entityId);
            recentDone.remove(railPos);
        }, ARROW_TTL);
        pendingCarts.put(railPos, new int[]{ cartDelay, 0 });
    }

    public void onClientTick(MinecraftClient mc) {
        tickSync.onClientTick();
        if (pendingCarts.isEmpty()) return;
        if (mc.player == null || mc.world == null) return;
        if (!enabled) { pendingCarts.clear(); return; }
        // Không xử lý khi đang draw cung
        if (mc.player.isUsingItem()) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> e = iter.next();
            BlockPos pos = e.getKey();
            int[] state  = e.getValue();

            state[0]--;
            if (state[0] > 0) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing() && mc.interactionManager != null) {
                    int saved = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(mc, pos);
                    mc.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_RETRY) {
                state[0] = 1;
                state[1]++;
            } else {
                iter.remove();
            }
        }
    }

    /** beforeSync — grim pattern: cart retry đi kèm movement packet. */
    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.player.isUsingItem()) return;
        // pendingCarts được xử lý trong onClientTick
    }
}
