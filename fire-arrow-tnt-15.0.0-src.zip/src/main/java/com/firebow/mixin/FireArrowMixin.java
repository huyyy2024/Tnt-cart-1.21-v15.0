package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.InteractionUtil;
import com.firebow.util.PlacementCalc;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Unique private int firebow$age = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        firebow$age++;
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        // Tên đã cắm hoặc dừng
        if (self.getVelocity().lengthSquared() < 0.0001) return;
        // Bắn xa rồi lại gần
        if (firebow$age > 40) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d pos  = self.getPos();
        Vec3d vel  = self.getVelocity();
        World world = self.getWorld();

        // Lấy precomputed từ bow release (nhanh hơn), fallback về trajectory
        BlockPos precomputed = rt.getAndClearPrecomputed();
        BlockPos railPos;

        if (precomputed != null
                && !rt.wasRecentlyPlaced(precomputed)
                && InteractionUtil.inReach(mc.player, precomputed)
                && mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(precomputed)) >= 1.0) {
            railPos = precomputed;
        } else {
            railPos = PlacementCalc.predictLandingRailPos(world, pos, vel);
            if (railPos == null) return;
            if (!InteractionUtil.inReach(mc.player, railPos)) return;
            if (rt.wasRecentlyPlaced(railPos)) return;
            if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.0) return;
            if (estimateTicksToLand(pos, vel, railPos) > 25) return;
        }

        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Đặt rail với rotation — Grim check hit vector khớp look direction
        int saved = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = target.railSlot.slot;
        InteractionUtil.placeBelow(mc, railPos);
        mc.player.getInventory().selectedSlot = saved;

        // Cart delay tự nhiên theo ping
        long ping = getPing(mc);
        int cartDelay = ping > 300 ? 4 : ping > 150 ? 3 : 2;
        rt.acceptArrow(entityId, railPos, cartDelay);
    }

    private int estimateTicksToLand(Vec3d pos, Vec3d vel, BlockPos t) {
        double x=pos.x,y=pos.y,z=pos.z,vx=vel.x,vy=vel.y,vz=vel.z;
        Vec3d tc = Vec3d.ofCenter(t);
        for (int i=0;i<60;i++) {
            vy-=0.05; vx*=0.99; vy*=0.99; vz*=0.99;
            x+=vx; y+=vy; z+=vz;
            if (Math.sqrt((x-tc.x)*(x-tc.x)+(y-tc.y)*(y-tc.y)+(z-tc.z)*(z-tc.z))<1.5) return i;
        }
        return 60;
    }

    private long getPing(MinecraftClient mc) {
        try {
            var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return e != null ? e.getLatency() : 50L;
        } catch (Exception ex) { return 50L; }
    }

    private boolean isOwnArrow(PersistentProjectileEntity a, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = a.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
